﻿namespace Unit4
{
    public class Stack<T>
    {
        private Node<T> data;

        public Stack()
        {
        }

        public bool IsEmpty()
        {
            return true;
        }

        public void Push(T x)
        {
        }

        public T Pop()
        {
            return data.GetValue();
        }

        public T Top()
        {
            return data.GetValue();
        }

        public override string ToString()
        {
            return "[1,2]";
        }
    }
}
