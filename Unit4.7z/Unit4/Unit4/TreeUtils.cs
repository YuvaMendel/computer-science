﻿using System;
//using VisualTree;

namespace Unit4
{
    // TNVH - TreeNodeValueHelper
    class TNVH<T>
    {
        public int left { get; }
        public int right { get; }
        public BinNode<T> node { get; }
        public TNVH(int left, int right, T value)
        {
            this.left = left;
            this.right = right;
            this.node = new BinNode<T>(value);
        }
    }
    class TreeUtils
    {
        public static int TreeSum(BinNode<int> t)
        {
                return 0;
        }
    }
}
