﻿namespace Unit4
{
    public class Queue<T>
    {
        private Node<T> first;
        private Node<T> last;

        public Queue()
        {
        }

        public bool IsEmpty()
        {
            return false;
        }

        public void Insert(T x)
        {
        }

        public T Remove()
        {
            return this.first.GetValue();
        }

        public T Head()
        {
            return this.first.GetValue();
        }

        public override string ToString()
        {
            return "[1,2,3]";
        }
    }
}
