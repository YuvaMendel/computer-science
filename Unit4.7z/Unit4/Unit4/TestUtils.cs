﻿using System;
using System.Diagnostics;
using System.Numerics;
//using VisualTree;

namespace Unit4
{
    public static class TestUtils
    {
        public static void Test_CreateListFromArray()
        {
            Console.WriteLine($"--- {(new StackTrace()).GetFrame(0).GetMethod()} ---");
            int[] a = { 4, 8, 2, 5, 8 };
            OtherUtils.ArrayPrint(a);

            Node<int> l1 = NodeUtils.CreateListFromArray(a);
            Node<int> l2 = NodeUtils.CreateListFromArrayR(a, 0);

            NodeUtils.PrintList(l1);
            NodeUtils.PrintListR(l2);

            if (NodeUtils.Compare(l1, l2))
                Console.WriteLine("Test Pass");
            else
                Console.WriteLine("Test Failed");

        }
        public static void Test_ReverseList()
        {
            Console.WriteLine($"--- {(new StackTrace()).GetFrame(0).GetMethod()} ---");
            int[] a = { 4, 8, 2, 5, 8 };
            Node<int> l1 = NodeUtils.CreateListFromArray(a);
            Node<int> l2 = NodeUtils.ReverseList(l1);

            int[] exp_result = { 8, 5, 2, 8, 4 };
            Node<int> exp_result_list = NodeUtils.CreateListFromArray(exp_result);
            if (NodeUtils.Compare(exp_result_list, l2))
                Console.WriteLine("Test Pass");
            else
                Console.WriteLine("Test Failed");
        }
    }
}

