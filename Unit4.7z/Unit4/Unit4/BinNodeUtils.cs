﻿using System;

namespace Unit4
{
    public static class BinNodeUtils
    {
        public static BinNode<T> CreateListFromArray<T>(T[] arr)
        {
            BinNode<T> head = new BinNode<T>(arr[0]);
            return head;
        }
        public static int Size<T>(BinNode<T> chain)
        {
            int count = 0;
            return count;
        }
        public static int Sum(BinNode<int> chain)
        {
            int sum = 0;
            return sum;
        }
        public static void PrintBinNode<T>(BinNode<T> lst)
        {
            Console.WriteLine("");
        }
    }
}