﻿using System;

namespace Unit4
{
    class QueueUtils
    {
        public static Queue<T> CreateQueueFromArray<T>(T[] arr)
        {
            Queue<T> s = new Queue<T>();
            return s;
        }
        public static void SpilledOn<T>(Queue<T> dest, Queue<T> src)
        {
        }

        public static Queue<T> Clone<T>(Queue<T> s)
        {
            Queue<T> t = new Queue<T>();
            Queue<T> s2 = new Queue<T>();

            return s2;
        }
        public static int GetSize<T>(Queue<T> q)
        {
            int count = 0;

            return count;
        }
        public static void InsertAtPos<T>(Queue<T> q, T e, int n)
        {
        }
        public static bool IsExist<T>(Queue<T> q, T e)
        {
            return false;
        }
        public static void Sort(Queue<int> q)
        {
        }
    }
}











