﻿using System;

namespace Unit4
{
    public static class NodeUtils
    {
        public static Node<T> CreateListFromArray<T>(T[] arr)
        {
            Node<T> head = null;
            for (int i = arr.Length -1 ; i >= 0; i--)
            {
                head = new Node<T>(arr[i], head);
            }
            return head;
        }
        public static Node<T> CreateListFromArrayR<T>(T[] arr, int i)
        {
            if (i == arr.Length)
            {
                return null;
            }
            return new Node<T>(arr[i], CreateListFromArrayR(arr, i+1));
        }
        public static void PrintList<T>(Node<T> l)
        {
            while (!(l == null))
            {
                Console.Write(l +"->");
                l = l.GetNext();
            }
            Console.WriteLine();
        }
        public static void PrintListR<T>(Node<T> l)
        {
            if (l == null)
            {
                Console.WriteLine();
                return;
            }
            Console.Write(l + "->");
            PrintListR(l.GetNext());
        }
        public static Node<T> CloneList<T>(Node<T> l)
        {
            if (l == null)
                return null;
            Node<T> head = new Node<T>(l.GetValue());
            return head;
        }

        public static Node<T> ReverseList<T>(Node<T> l)/////////////NOT WORKING CONTINUE HERE
        {
            Node<T> last = l;
            Node<T> reverse = new Node<T>(l.GetValue());
            Node<T> reversehead = reverse;
            while (l.HasNext())
            {
                l = l.GetNext();
                reverse.SetNext(l);
            }
        }
        public static Node<T> ReverseListR<T>(Node<T> l)
        {
            return null;
        }
        public static bool Exist(Node<int> t, int val)
        {
            return false;
        }
        public static bool Compare(Node<int> left, Node<int> right)
        {
            while (left != null && right != null)
            {
                if (left.GetValue() != right.GetValue())
                {
                    return false;
                }
                left = left.GetNext();
                right = right.GetNext();
            }
            return right == null && left == null;
        }
        public static int GetChainLength<T>(Node<T> chain)
        {
            return 0;
        }
    }
}
