﻿namespace Unit4
{
    public class BinNode<T>
    {
        private BinNode<T> left;
        private T value;
        private BinNode<T> right;

        public BinNode(T value)
        {
        }
        public BinNode(BinNode<T> left, T value, BinNode<T> right)
        {
        }
        public T GetValue()
        {
            return value;
        }
        public BinNode<T> GetLeft()
        {
            return left;
        }
        public BinNode<T> GetRight()
        {
            return right;
        }
        public bool HasLeft()
        {
            return false;
        }
        public bool HasRight()
        {
            return false;
        }
        public void SetValue(T value)
        {
        }
        public void SetLeft(BinNode<T> left)
        {
        }
        public void SetRight(BinNode<T> right)
        {
        }
        // This method was added to use for printing Tree
        public override string ToString()
        {
            return "";
        }
    }
}
