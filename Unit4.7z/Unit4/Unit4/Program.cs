﻿using System;

namespace Unit4
{
    class Program
    {
        static void Main(string[] args)
        {
            int[] test_case = { };
            if (test_case.Length == 0)
            {
                Console.Write("enter test number: ");
                test_case = new int[1];
                test_case[0] = int.Parse(Console.ReadLine());
            }
            for (int i = 0; i < test_case.Length; i++)
            {
                switch (test_case[i])
                {
                    case 0:
                        break;
                    case 1:
                        TestUtils.Test_CreateListFromArray();
                        break;
                    case 2:
                        TestUtils.Test_ReverseList();
                        break;
                    case 3:
                        //TestUtils.Test_();
                        break;
                    case 4:
                        //TestUtils.();
                        break;
                    case 104:
                        //TestUtils.();
                        break;
                    case 105:
                        //TestUtils.();
                        break;
                    case 106:
                        //TestUtils.();
                        break;
                    case 107:
                        //TestUtils.();
                        break;
                    case 108:
                        //TestUtils.();
                        break;
                    case 109:
                        //TestUtils.();
                        break;
                    default:
                        break;
                }
            }
            Console.ReadLine();
        }
    }
}
